package com.wipro.test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.test.model.IncomingTest;
import com.wipro.test.model.OutgoingTest;
import com.wipro.test.service.AssignmentService;

@RestController
@RequestMapping(value = "/api")
public class AssignmentController {

	@Autowired
	private AssignmentService service;

	@PostMapping(value = "/create")
	public String create(@RequestParam("id") int randomInt, IncomingTest incomingTest) {
		incomingTest.setRandomInt(randomInt);
		service.createRecord(incomingTest);
		return "Records created.";
	}
	
	@GetMapping(value= "/numbersMeetNumbers")
    public OutgoingTest getAll() {
        return service.numbersMeetNumbers();
    }
	
	@GetMapping(value= "/findDuplicates")
    public List<IncomingTest> findDuplicates() {
        return service.findDuplicates();
    }
	
}
