package com.wipro.test.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.wipro.test.model.IncomingTest;
import com.wipro.test.model.OutgoingTest;

@Repository
public interface AssignmentRepository extends MongoRepository<IncomingTest, Integer> {

	OutgoingTest findTopByOrderByOrderDateDesc();

}
