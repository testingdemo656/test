package com.wipro.test.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.wipro.test.model.OutgoingTest;

@Repository
public class AssignmentRepositoryCustom {

	@Autowired
	private MongoTemplate mongoTemplate;

}
