package com.wipro.test.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.test.model.IncomingTest;
import com.wipro.test.model.OutgoingTest;
import com.wipro.test.repository.AssignmentRepository;

@Service
public class AssignmentService {

	@Autowired
	private AssignmentRepository repository;

	public void createRecord(IncomingTest incomingTest) {
		repository.save(incomingTest);
	}

	public OutgoingTest numbersMeetNumbers() {
		return repository.findTopByOrderByOrderDateDesc();
	}

	public List<IncomingTest> findDuplicates() {
		return repository.findAll();
	}
	
}
