package com.wipro.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WiproTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(WiproTestApplication.class, args);
	}

}
